# Archived LAGEOS-1 reader inputs

Retrieved from the public EUROLAS Data Center (DGFI-TUM) and ILRS archives on 2026-10-15.
`provenance.json` pins original URLs, download hashes and uncompressed hashes.

- `lageos1_20240402.np2`: complete provider daily CRDv2 normal-point product,
  unchanged. Includes meteorology and calibration40/41 records. The retained Graz
 7839 data use UTC(GPS) epoch tags, event2, range-type2, CoM/refraction flags0 and
  station-system-delay flag1. Calibration is already applied; no physical
  correction has been reapplied to these source bytes.
- `ilrsa.orb.lageos1.240406.v81.sp3`: complete provider final combined fitted
  weekly orbit,2024-03-31 through2024-04-06. Only gzip decompression was applied.
  Header declares UTC, SLR20/SLRF2020, FIT and120-second samples; positions are
  km and velocities dm/s in the source. Clock sentinels do not constitute a
  satellite clock solution. This is not a CPF prediction.

- `SLRF2020_POS+VEL_2023.10.02.snx`: complete provider SINEX position and
  velocity release, unchanged, including indented `+SNX` INPUT/HISTORY
  records. Graz 7839/A/1 (11001S002) and Herstmonceux 7840/A/1 (13212S001)
  supply Cartesian positions at 2015-01-01 and velocities in metres/year.
  Provider comments retain the ITRF2020/SLRF2020 frame and motion-model
  requirements. Cite ILRS, IGN-IPGP and the provider credits in the file.

These are file-format/model-input tests, not frozen observation residuals or a
claim of independent orbit accuracy. The observation/orbit fit shares SLR data.
Full scientific reduction also requires consistent station/EOP histories,
eccentricities, atmospheric delay, target signature and ILRS Data Handling File.

Cite the International Laser Ranging Service, the EDC/DGFI-TUM data centre and
SLR orbit product DOI10.5067/SLR/SLR_ILRSORB_001. Official description:
https://edc.dgfi.tum.de/en/products/precise-orbits/
CRD specification:
https://ilrs.gsfc.nasa.gov/docs/2022/crd_v2.01e3.pdf

No explicit per-file redistribution licence is supplied in the provider headers;
these public scientific data retain their original provenance and are not
relicensed as Tudat code. Provider acknowledgement/citation is required for
scientific use; no additional redistribution rights are asserted here.
