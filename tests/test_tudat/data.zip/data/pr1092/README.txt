PR1092 C++ test fixtures and reference generation material
========================================================

All PR1092 fixtures, generated C++ headers, reference drivers, generation and
extraction scripts, provenance records and licences live only in this archive.
The unpack_test_data target extracts them to <build>/tests/data/pr1092/.
Paths below reference_files/ and src/ retain their old tests/test_tudat-relative
layout. manifest.json records each original source path, byte count and SHA-256.

C++ runtime readers use getTudatTestDataPath() + "pr1092/...". Generated headers
are included as "pr1092/...h" through the build-tree tests/data include path;
archive extraction is a prerequisite for the consuming test targets. No loose
source-tree fixture copy or runtime download is required.

The archived README files describe how to regenerate or extract individual
references. For regeneration, reconstruct the old tests/test_tudat-relative
layout in a source checkout and follow the relevant README. Some generators
update test source or need pinned external provider files and optional reference
compilers. The scripts are not run by the C++ tests. Original provider bytes,
line endings, source notices and licences are retained.
