PR1092 C++ test data
===================

This directory contains byte-identical snapshots of the external fixtures,
reference drivers, generation/extraction scripts, provenance, licenses and
required resource additions introduced by PR1092. manifest.json records the
source paths, sizes and SHA-256 checksums. Paths below reference_files/ and
src/ preserve their tests/test_tudat-relative layout; resources/ preserves its
repository-relative layout.

The existing unpack_test_data target extracts this bundle to
<build>/tests/data/pr1092/. No download or reference-code execution is needed
to extract it. Existing archive entries are unchanged.

Source copies remain in the repository: generated fixture headers are included
at compile time, and current tests read several fixtures relative to __FILE__.
The seven resources also remain in resources/ for the existing CI copy step.
This archive does not replace those source paths or the resource installation.

For regeneration, follow each directory's README and provenance manifest in a
source checkout. Some scripts read or update C++ test source, or require pinned
external provider files and optional reference compilers; those requirements
are unchanged. This bundle does not include downloaded provider caches or
executables, and generation scripts are not run by the C++ tests.
