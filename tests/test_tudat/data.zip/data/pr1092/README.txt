PR1092 C++ test data: reference generation material
=================================================

This directory contains the material used to generate or extract the reference
data of the PR1092 C++ tests, which the tests themselves do not read: README
files, provenance and source manifests, generation and extraction scripts,
reference drivers (Fortran/C) and the pinned IERS HARDISP source code.
manifest.json lists the original repository path, size and SHA-256 checksum of
each file. Paths below reference_files/ and src/ keep their tests/test_tudat
layout.

The fixtures and generated headers that the tests read or include directly stay
in the repository, at the same paths (for instance
tests/test_tudat/reference_files/station_history/*.snx or
tests/test_tudat/src/astro/earth_orientation/short_period_reference/fixtures.h).
The IERS licence files are kept in both places.

The unpack_test_data target extracts this directory to
<build>/tests/data/pr1092/. To regenerate a fixture, copy the directory of
interest next to the corresponding repository directory and follow its README;
some scripts write the generated files into their own directory, and some need
pinned external provider files or reference compilers. The generation scripts
are not run by the tests.
