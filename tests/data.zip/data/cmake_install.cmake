# Install script for directory: /home/dominic/Software/tudat-team-test/tudat-bundle/tudat/tests

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for each subdirectory.
  include("/home/dominic/Software/tudat-team-test/tudat-bundle/build-tudat-Desktop-Default/tests/src/astro/cmake_install.cmake")
  include("/home/dominic/Software/tudat-team-test/tudat-bundle/build-tudat-Desktop-Default/tests/src/basics/cmake_install.cmake")
  include("/home/dominic/Software/tudat-team-test/tudat-bundle/build-tudat-Desktop-Default/tests/src/interface/cmake_install.cmake")
  include("/home/dominic/Software/tudat-team-test/tudat-bundle/build-tudat-Desktop-Default/tests/src/math/cmake_install.cmake")
  include("/home/dominic/Software/tudat-team-test/tudat-bundle/build-tudat-Desktop-Default/tests/src/simulation/cmake_install.cmake")
  include("/home/dominic/Software/tudat-team-test/tudat-bundle/build-tudat-Desktop-Default/tests/src/io/cmake_install.cmake")

endif()

